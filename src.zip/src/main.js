import Vue from 'vue'
import App from './App.vue'
import VueRouter from 'vue-router'
import router from './router'
import $ from 'jquery'
import axios from 'axios'

import "bootstrap"
import "bootstrap/dist/css/bootstrap.css"

import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'

Vue.use(ElementUI)
Vue.prototype.$axios=axios;
Vue.use(VueRouter)
Vue.config.productionTip = false

new Vue({
    el: '#app',
    router,
    render: h => h(App)
})