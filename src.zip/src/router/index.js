
import Vue from 'vue'
import Router from 'vue-router'
import login from '../components/login.vue'
import center from '../components/center'
Vue.use(Router)
const index = [
    {
        path: '/login',
        name: 'login',
        component: login
    },
    {
        path: '/',
        redirect:'/login'
    },
    {
        path: '/center',
        name: 'center',
        component: center
    },
]
export default new Router({
    routes: index
})
